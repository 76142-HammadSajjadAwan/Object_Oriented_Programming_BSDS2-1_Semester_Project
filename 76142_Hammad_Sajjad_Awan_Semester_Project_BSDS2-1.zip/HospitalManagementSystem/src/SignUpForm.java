/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */

/**
 *
 * @author Cyber Zone
 */
import java.io.*;
import java.util.*;
import javax.swing.JOptionPane;
public class SignUpForm extends javax.swing.JFrame {
    
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(SignUpForm.class.getName());

    /**
     * Creates new form SignUpForm
     */
    
 
    public SignUpForm() {
        initComponents();
    }


    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        SignUpPanel = new javax.swing.JPanel();
        SignUpLabel = new javax.swing.JLabel();
        RegistrationLabel = new javax.swing.JLabel();
        NameLabel = new javax.swing.JLabel();
        UsernameLabel = new javax.swing.JLabel();
        PasswordLabel = new javax.swing.JLabel();
        ConfirmPasswordLabel = new javax.swing.JLabel();
        CreateAccountButton = new javax.swing.JButton();
        NameTextField = new javax.swing.JTextField();
        UsernameTextField = new javax.swing.JTextField();
        PasswordField = new javax.swing.JPasswordField();
        ConfirmPasswordField = new javax.swing.JPasswordField();
        AlreadyLabel = new javax.swing.JLabel();
        LoginButton = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        SignUpPanel.setBackground(new java.awt.Color(255, 255, 255));

        SignUpLabel.setBackground(new java.awt.Color(255, 255, 255));
        SignUpLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Sign Up.jpeg"))); // NOI18N

        RegistrationLabel.setBackground(new java.awt.Color(255, 255, 255));
        RegistrationLabel.setFont(new java.awt.Font("Segoe UI", 3, 36)); // NOI18N
        RegistrationLabel.setForeground(new java.awt.Color(0, 0, 255));
        RegistrationLabel.setText("  Create New Account");

        NameLabel.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        NameLabel.setText("Full Name:");

        UsernameLabel.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        UsernameLabel.setText("Username:");

        PasswordLabel.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        PasswordLabel.setText("Password:");

        ConfirmPasswordLabel.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        ConfirmPasswordLabel.setText("Confirm Password:");

        CreateAccountButton.setBackground(new java.awt.Color(0, 0, 255));
        CreateAccountButton.setFont(new java.awt.Font("Segoe UI", 3, 14)); // NOI18N
        CreateAccountButton.setForeground(new java.awt.Color(242, 242, 242));
        CreateAccountButton.setText("Create Account");
        CreateAccountButton.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                CreateAccountButtonMouseClicked(evt);
            }
        });
        CreateAccountButton.addActionListener(this::CreateAccountButtonActionPerformed);

        NameTextField.addActionListener(this::NameTextFieldActionPerformed);

        UsernameTextField.addActionListener(this::UsernameTextFieldActionPerformed);

        PasswordField.addActionListener(this::PasswordFieldActionPerformed);

        ConfirmPasswordField.addActionListener(this::ConfirmPasswordFieldActionPerformed);

        AlreadyLabel.setFont(new java.awt.Font("Segoe UI", 3, 12)); // NOI18N
        AlreadyLabel.setForeground(new java.awt.Color(0, 102, 102));
        AlreadyLabel.setText("Do you have already account?");

        LoginButton.setBackground(new java.awt.Color(0, 0, 255));
        LoginButton.setFont(new java.awt.Font("Segoe UI", 3, 14)); // NOI18N
        LoginButton.setForeground(new java.awt.Color(242, 242, 242));
        LoginButton.setText("Login");
        LoginButton.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                LoginButtonMouseClicked(evt);
            }
        });
        LoginButton.addActionListener(this::LoginButtonActionPerformed);

        javax.swing.GroupLayout SignUpPanelLayout = new javax.swing.GroupLayout(SignUpPanel);
        SignUpPanel.setLayout(SignUpPanelLayout);
        SignUpPanelLayout.setHorizontalGroup(
            SignUpPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(SignUpPanelLayout.createSequentialGroup()
                .addGroup(SignUpPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(RegistrationLabel, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 377, Short.MAX_VALUE)
                    .addGroup(SignUpPanelLayout.createSequentialGroup()
                        .addGroup(SignUpPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(SignUpPanelLayout.createSequentialGroup()
                                .addGap(72, 72, 72)
                                .addComponent(SignUpLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 231, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(SignUpPanelLayout.createSequentialGroup()
                                .addGap(21, 21, 21)
                                .addGroup(SignUpPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(ConfirmPasswordLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(PasswordLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(UsernameLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(NameLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(SignUpPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(NameTextField)
                                    .addComponent(UsernameTextField, javax.swing.GroupLayout.DEFAULT_SIZE, 193, Short.MAX_VALUE)
                                    .addComponent(PasswordField)
                                    .addComponent(ConfirmPasswordField))))
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, SignUpPanelLayout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(CreateAccountButton)
                .addGap(18, 18, 18))
            .addGroup(SignUpPanelLayout.createSequentialGroup()
                .addGap(97, 97, 97)
                .addComponent(AlreadyLabel)
                .addGap(18, 18, 18)
                .addComponent(LoginButton)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        SignUpPanelLayout.setVerticalGroup(
            SignUpPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(SignUpPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(SignUpLabel)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(RegistrationLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 51, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(SignUpPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(NameLabel)
                    .addComponent(NameTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(SignUpPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(UsernameLabel)
                    .addComponent(UsernameTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(SignUpPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(PasswordLabel)
                    .addComponent(PasswordField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(SignUpPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(ConfirmPasswordLabel)
                    .addComponent(ConfirmPasswordField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(CreateAccountButton)
                .addGap(18, 18, 18)
                .addGroup(SignUpPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(AlreadyLabel)
                    .addComponent(LoginButton))
                .addContainerGap(33, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(SignUpPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(SignUpPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void CreateAccountButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CreateAccountButtonActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_CreateAccountButtonActionPerformed

    private void NameTextFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_NameTextFieldActionPerformed
                                                                 
    try {
        String name = NameTextField.getText().trim();
        if (!name.isEmpty() && !name.matches("^[a-zA-Z\\s]+$")) {
            throw new Exception("Full Name must contain alphabets only!");
        }
    } catch (Exception e) {
        JOptionPane.showMessageDialog(this, e.getMessage(), "Input Error", JOptionPane.WARNING_MESSAGE);
        NameTextField.requestFocusInWindow();
    }
    }//GEN-LAST:event_NameTextFieldActionPerformed

    private void UsernameTextFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_UsernameTextFieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_UsernameTextFieldActionPerformed

    private void PasswordFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_PasswordFieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_PasswordFieldActionPerformed

    private void ConfirmPasswordFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ConfirmPasswordFieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_ConfirmPasswordFieldActionPerformed

    private void LoginButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_LoginButtonActionPerformed
         LoginForm login = new LoginForm();
        this.dispose();
        login.setVisible(true);
    }//GEN-LAST:event_LoginButtonActionPerformed
    private void LoginButtonMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_LoginButtonMouseClicked

    }//GEN-LAST:event_LoginButtonMouseClicked

    private void CreateAccountButtonMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_CreateAccountButtonMouseClicked
    String errorMessages = ""; 

    try {
        String fullName = NameTextField.getText().trim();
        String user = UsernameTextField.getText().trim();
        String pass = new String(PasswordField.getPassword());
        String confirm = new String(ConfirmPasswordField.getPassword());

        // 1. Basic Empty Checks
        if (fullName.isEmpty()) {errorMessages += "- Full Name cannot be empty!\n";}
        if (user.isEmpty()){ errorMessages += "- Username cannot be empty!\n";}

        // 2. Duplicate Username Check
        File file = new File("users.txt");
        if (file.exists() && !user.isEmpty()) {
            Scanner reader = new Scanner(file);
            while (reader.hasNextLine()) {
                String line = reader.nextLine();
                String[] parts = line.split(",");
                if (parts.length > 0 && user.equalsIgnoreCase(parts[0].trim())) {
                    errorMessages += "- This Username is already registered!\n";
                    break; 
                }
            }
            reader.close();
        }

        // 3. Password Length Check
        if (pass.length() < 4) {
            errorMessages += "- Password must be at least 4 characters long!\n";
        }

        // 4. Password Match Check
        if (!pass.equals(confirm)) {
            errorMessages += "- Passwords do not match!\n";
        }

        // --- FINAL ERROR CHECK ---
        if (!errorMessages.equals("")) {
            throw new Exception(errorMessages);
        }

        
        FileWriter fw = new FileWriter(file, true);
        BufferedWriter bw = new BufferedWriter(fw);
        bw.write(user + "," + pass);
        bw.newLine();
        bw.close();
        fw.close();

        javax.swing.JOptionPane.showMessageDialog(this, "Account Registered Successfully!", "Success", 1);
        this.dispose();
        new LoginForm().setVisible(true);

    } catch (Exception e) {
        // Ab yahan aik sath saare errors nazar aayenge
        javax.swing.JOptionPane.showMessageDialog(this, e.getMessage(), "Registration Error", 0);
    }
    }//GEN-LAST:event_CreateAccountButtonMouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> new SignUpForm().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel AlreadyLabel;
    private javax.swing.JPasswordField ConfirmPasswordField;
    private javax.swing.JLabel ConfirmPasswordLabel;
    private javax.swing.JButton CreateAccountButton;
    private javax.swing.JButton LoginButton;
    private javax.swing.JLabel NameLabel;
    private javax.swing.JTextField NameTextField;
    private javax.swing.JPasswordField PasswordField;
    private javax.swing.JLabel PasswordLabel;
    private javax.swing.JLabel RegistrationLabel;
    private javax.swing.JLabel SignUpLabel;
    private javax.swing.JPanel SignUpPanel;
    private javax.swing.JLabel UsernameLabel;
    private javax.swing.JTextField UsernameTextField;
    // End of variables declaration//GEN-END:variables
}
