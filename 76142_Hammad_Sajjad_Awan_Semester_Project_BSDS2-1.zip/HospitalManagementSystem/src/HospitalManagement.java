/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Cyber Zone
 */
public class HospitalManagement {
    public static void main(String[] args) {
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (Exception e) {
            System.out.println("Theme Error: " + e.getMessage());
        }

        java.awt.EventQueue.invokeLater(() -> {
            LoginForm login = new LoginForm(); 
            login.setVisible(true);
            login.setLocationRelativeTo(null); 
        });
    }
}
 abstract class Person {
    protected String FirstName,LastName,Cnic;
    protected int age;
    protected String gender,contactNumber,email;
    public abstract String performDuty();
     Person(String FirstName, String LastName, String Cnic, int age, String gender, String contactNumber,String email)
    {
        this.FirstName=FirstName;
        this.LastName=LastName;
        this.Cnic=Cnic;
        this.age=age;
        this.gender=gender;
        this.contactNumber=contactNumber;
        this.email=email;
    }
     //getters
    public String getFirstName()
    {
        return FirstName;
    }
    public String getLastName()
    {
        return LastName;
    }
    public String getCnic()
    {
        return Cnic;
    }
    public int getAge()
    {
        return age;
    }
    public String getGender()
    {
        return gender;
    }
    public String getContactNumber()
    {
        return contactNumber;
    }
     public String getEmail()
    {
        return email;
    }
     //Setters
     public void setFirstName(String FirstName)
     {
         this.FirstName=FirstName;
     }
     public void setLastName(String LastName)
     {
         this.LastName=LastName;
     }
     public void setCnic(String Cnic)
     {
         this.Cnic=Cnic;
     }
     public void setAge(int age)
     {
         this.age=age;
     }
     public void setGender(String gender)
     {
         this.gender=gender;
     }
     public void setContactNumber(String contactNumber)
     {
         this.contactNumber=contactNumber;
     }
    public void setEmail(String email)
    {
        this.email=email;
    }
    public String displayInfo() {
    return "Basic Info: " + FirstName + " " + LastName;
 }
}
 class Patient extends Person{
    private double weight;
    private String maritalStatus,dob,city,province;
    private String emergencyFirstName;
    private String emergencyLastName;
    private String relationship;
    private String emergencyContact;
    
   public Patient(String FirstName, String LastName, String Cnic, int age, String gender,String contactNumber,String email,double weight,String maritalStatus, String dob,String city,String province,String emergencyFirstName,String emergencyLastName,String relationship,String emergencyContact)
    {
        super(FirstName,LastName,Cnic,age,gender,contactNumber,email);
        this.weight=weight;
        this.maritalStatus=maritalStatus;
        this.dob=dob;
        this.city=city;
        this.province=province;
        this.emergencyFirstName=emergencyFirstName;
        this.emergencyLastName=emergencyLastName;
        this.relationship=relationship;
        this.emergencyContact=emergencyContact;
    }
public String displayInfo() {
    return "Patient: " + FirstName + " " + LastName + "\nCNIC: " + Cnic + "\nContact: " + contactNumber+"\nGender: "+gender;
}

public String performDuty() {
    return "Patient is currently undergoing registration and initial diagnosis.";
}
}
class Doctor extends Person
{
    private String doctorID,specialization,qualification,experience,clinicAddress;
    private double fee;
    private String availability;
    
    Doctor(String FirstName,String doctorID,String specialization,String qualification, 
            String experience,double fee,String clinicAddress,String contactNumber,
            String availability,String email)
    {
        super(FirstName," ","N/O",0,"not specified",contactNumber,email);
        this.doctorID=doctorID;
        this.specialization=specialization;
        this.qualification=qualification;
        this.experience=experience;
        this.clinicAddress=clinicAddress;
        this.fee=fee;
        this.availability=availability;
    }
   public String getDoctorId()
   {
       return doctorID;
   }
   public String getSpecialization()
   {
       return specialization;
   }
   public String getQualification()
   {
       return qualification;
   }
   public String getExperience()
   {
       return experience;
   }
   public String getClinicAddress()
   {
       return clinicAddress;
   }
   public double getFee()
   {
       return fee;
   }
   public String getAvailability()
   {
       return availability;
   }
   public String getFullName()
   {
       return FirstName;
   }
    @Override
    public String performDuty() {
        return ("Duty: Doctor " + FirstName + " is treating patients and prescribing medicine.");
    }
    @Override
   public String displayInfo() {
        return ("Doctor ID: " + doctorID + " | Name: " + FirstName + " | Spec: " + specialization);
    }
}

